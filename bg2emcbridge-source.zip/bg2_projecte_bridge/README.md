# BG2 EMC Bridge

A small NeoForge 1.21.1 mod that lets **Building Gadgets 2** pull blocks directly
from your **ProjectE** EMC network — no inventory restocking required.

## What it does

When any gadget (Building, Exchanging, Copy/Paste) needs a block that isn't in
your inventory, AE2 network, bound container, or Curios slots, it automatically
transmutes it from your stored EMC — just like standing at a Transmutation Table.

- Ghost block **preview turns green** for anything you can afford from EMC
- EMC is only spent when the build actually executes (not on the preview pass)
- If your EMC drops too low between aiming and clicking, the build is cancelled safely
- EMC is the **last resort** — inventory, AE2, bound containers, and Curios are all checked first

## Requirements

- Item must be **learned/unlocked** in your Transmutation Table
- You must have **enough stored EMC** to cover the blocks needed

## Installation

Drop `bg2emcbridge-1.0.4.jar` into your `mods/` folder alongside:
- Building Gadgets 2 1.3.9+
- ProjectE PE1.1.0+
- NeoForge 21.1.172+

## Building from source

Requires **JDK 21**.

1. Clone this repo
2. Copy `buildinggadgets2-1.3.9.jar` and `ProjectE-1.21.1-PE1.1.0.jar` into `libs/`
3. Run `./gradlew build`
4. Output: `build/libs/bg2emcbridge-1.0.4.jar`

## How it works

Two Mixins on `BuildingUtils` (the class BG2 routes all item consumption through):

**`MixinBuildingUtils`** — hooks `removeStacksFromInventory` (server-side).
After BG2 finishes checking all its normal sources and returns false, we check
the shortfall against the player's EMC balance and spend EMC to cover it.

**`MixinBuildingUtilsCount`** — hooks `countItemStacks` (client-side).
BG2 calls this every render frame to colour ghost blocks green or red.
We add the player's EMC-affordable quantity on top of whatever BG2 found,
so blocks covered by EMC also appear green in the preview.

## Compatibility

- ✅ Applied Energistics 2
- ✅ Sophisticated Backpacks / Storage
- ✅ Curios API
- ✅ Project Expansion
- ✅ General large modpacks

## Credits

Built through a collaborative debugging session between Claude (Anthropic) and
ChatGPT (OpenAI) — with Phillip doing the in-game testing and keeping us honest.

## License

MIT — free to use, modify, and redistribute.
