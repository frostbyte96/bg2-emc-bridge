package com.example.bg2emcbridge;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import org.slf4j.Logger;

/**
 * BG2 EMC Bridge — NeoForge 1.21.1
 *
 * Hooks into Building Gadgets 2's item-retrieval system via a Mixin on
 * BuildingUtils.removeStacksFromInventory.
 *
 * When a gadget needs items that aren't in your inventory (or AE2 network),
 * this mod checks your ProjectE transmutation knowledge and spends EMC to
 * fulfil the request — exactly like using the Transmutation Table, but
 * automatically and in-line with gadget use.
 *
 * Requirements:
 *  - You must have unlocked the target block in ProjectE (learned it)
 *  - You must have enough stored EMC to afford the quantity required
 *
 * Works with: Building Gadget, Exchanging Gadget, Copy/Paste Gadget
 */
@Mod(BG2EMCBridge.MOD_ID)
public class BG2EMCBridge {

    public static final String MOD_ID = "bg2emcbridge";
    public static final Logger LOGGER = LogUtils.getLogger();

    public BG2EMCBridge(IEventBus modEventBus, ModContainer container) {
        modEventBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("[BG2 EMC Bridge] Loaded. Building Gadgets will now pull from your ProjectE EMC network.");
        LOGGER.info("[BG2 EMC Bridge] Remember: items must be learned (unlocked) in your Transmutation Table.");
    }
}
