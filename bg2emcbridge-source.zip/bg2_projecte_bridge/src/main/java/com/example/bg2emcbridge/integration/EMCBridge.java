package com.example.bg2emcbridge.integration;

import com.example.bg2emcbridge.BG2EMCBridge;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.api.proxy.ITransmutationProxy;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.math.BigInteger;
import java.util.List;

/**
 * Core logic for fulfilling item shortfalls from the ProjectE EMC network.
 *
 * KEY INSIGHT from bytecode analysis of BuildingUtils.removeStacksFromInventory:
 *
 *   BG2 makes an INTERNAL COPY of neededItems and works on that copy.
 *   The original list is NEVER mutated. BG2's check order is:
 *   AE2 -> Bound Handler -> Curios -> Player Inventory.
 *   Returns false when the internal copy is non-empty after all checks.
 *
 * Our Mixin fires at RETURN when BG2 returns false (couldn't fill everything).
 *
 * HOW WE FIND THE SHORTFALL:
 *   For each item in neededItems, count how many the player currently has in
 *   their inventory RIGHT NOW. Shortfall = neededCount - currentInventoryCount.
 *
 *   simulate=true:  nothing consumed yet, shortfall = what AE2+inventory can't cover.
 *   simulate=false: BG2 already consumed from AE2/inventory. Shortfall = truly missing.
 */
public class EMCBridge {

    public static boolean tryFulfillFromEMC(Player player, List<ItemStack> neededItems, boolean simulate) {
        if (neededItems == null || neededItems.isEmpty()) return false;
        if (player.level().isClientSide()) return false;

        IKnowledgeProvider knowledge = getKnowledge(player);
        if (knowledge == null) return false;

        IEMCProxy emcProxy;
        try {
            emcProxy = IEMCProxy.INSTANCE;
            if (emcProxy == null) return false;
        } catch (Exception e) {
            BG2EMCBridge.LOGGER.warn("[BG2 EMC Bridge] IEMCProxy not available: {}", e.getMessage());
            return false;
        }

        BigInteger currentEmc = knowledge.getEmc();
        BigInteger totalEmcCost = BigInteger.ZERO;
        boolean allCovered = true;

        for (ItemStack needed : neededItems) {
            if (needed == null || needed.isEmpty()) continue;

            int totalNeeded = needed.getCount();
            int inInventory = countInInventory(player.getInventory(), needed);
            int shortfall = Math.max(0, totalNeeded - inInventory);
            if (shortfall <= 0) continue;

            if (!knowledge.hasFullKnowledge() && !knowledge.hasKnowledge(needed)) {
                BG2EMCBridge.LOGGER.debug("[BG2 EMC Bridge] Not learned: {}", needed.getHoverName().getString());
                allCovered = false;
                continue;
            }

            long emcPerItem;
            try {
                emcPerItem = emcProxy.getValue(needed);
            } catch (Exception e) {
                allCovered = false;
                continue;
            }
            if (emcPerItem <= 0) {
                allCovered = false;
                continue;
            }

            BigInteger cost = BigInteger.valueOf(emcPerItem).multiply(BigInteger.valueOf(shortfall));
            BigInteger remainingEmc = currentEmc.subtract(totalEmcCost);

            if (remainingEmc.compareTo(cost) < 0) {
                BG2EMCBridge.LOGGER.debug("[BG2 EMC Bridge] Not enough EMC for {}x {}",
                        shortfall, needed.getHoverName().getString());
                allCovered = false;
                continue;
            }

            totalEmcCost = totalEmcCost.add(cost);
            BG2EMCBridge.LOGGER.debug("[BG2 EMC Bridge] {} {}x {} via EMC (cost: {}, simulate: {})",
                    simulate ? "Would provide" : "Providing",
                    shortfall, needed.getHoverName().getString(), cost, simulate);
        }

        if (!simulate && totalEmcCost.compareTo(BigInteger.ZERO) > 0) {
            BigInteger newEmc = currentEmc.subtract(totalEmcCost);
            if (newEmc.compareTo(BigInteger.ZERO) < 0) newEmc = BigInteger.ZERO;
            knowledge.setEmc(newEmc);
            if (player instanceof ServerPlayer sp) {
                knowledge.syncEmc(sp);
            }
            BG2EMCBridge.LOGGER.info("[BG2 EMC Bridge] Spent {} EMC for gadget use.", totalEmcCost);
        }

        return allCovered;
    }

    private static int countInInventory(Inventory inventory, ItemStack target) {
        int count = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack slot = inventory.getItem(i);
            if (!slot.isEmpty() && ItemStack.isSameItemSameComponents(slot, target)) {
                count += slot.getCount();
            }
        }
        return count;
    }

    private static IKnowledgeProvider getKnowledge(Player player) {
        try {
            ITransmutationProxy proxy = ITransmutationProxy.INSTANCE;
            if (proxy == null) return null;
            return proxy.getKnowledgeProviderFor(player.getUUID());
        } catch (Exception e) {
            BG2EMCBridge.LOGGER.warn("[BG2 EMC Bridge] Could not get knowledge provider: {}", e.getMessage());
            return null;
        }
    }
}
