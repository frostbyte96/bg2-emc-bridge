package com.example.bg2emcbridge.integration;

import com.example.bg2emcbridge.BG2EMCBridge;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.api.proxy.ITransmutationProxy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.math.BigInteger;

/**
 * Lightweight EMC affordability check used by the ghost block preview.
 *
 * Called every render frame by our countItemStacks hook, so it must be fast.
 * ProjectE keeps knowledge and EMC synced to the client, so ITransmutationProxy
 * works on both sides.
 *
 * Returns the number of items the player could afford from EMC right now.
 * We cap at 64 * 1000 (64,000) so the int return is safe and the preview
 * stays green for even very large paste operations.
 */
public class EMCClientCache {

    private static final int MAX_VIRTUAL_COUNT = 64_000;

    public static int getAffordableCount(Player player, ItemStack itemStack) {
        if (itemStack == null || itemStack.isEmpty()) return 0;

        try {
            ITransmutationProxy transmutProxy = ITransmutationProxy.INSTANCE;
            if (transmutProxy == null) return 0;

            IKnowledgeProvider knowledge = transmutProxy.getKnowledgeProviderFor(player.getUUID());
            if (knowledge == null) return 0;

            // Check knowledge
            if (!knowledge.hasFullKnowledge() && !knowledge.hasKnowledge(itemStack)) return 0;

            IEMCProxy emcProxy = IEMCProxy.INSTANCE;
            if (emcProxy == null) return 0;

            long emcPerItem = emcProxy.getValue(itemStack);
            if (emcPerItem <= 0) return 0;

            BigInteger storedEmc = knowledge.getEmc();
            if (storedEmc.compareTo(BigInteger.valueOf(emcPerItem)) < 0) return 0;

            // How many can they afford?
            long affordable = storedEmc.divide(BigInteger.valueOf(emcPerItem)).longValue();
            return (int) Math.min(affordable, MAX_VIRTUAL_COUNT);

        } catch (Exception e) {
            // Don't spam logs every frame - just return 0
            return 0;
        }
    }
}
