package com.example.bg2emcbridge.mixin;

import com.direwolf20.buildinggadgets2.util.BuildingUtils;
import com.example.bg2emcbridge.integration.EMCBridge;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Injects into BuildingUtils.removeStacksFromInventory after BG2 has finished
 * all its normal checks (AE2 -> Bound Handler -> Curios -> Inventory).
 *
 * If BG2 returns false (couldn't fulfill everything), we attempt to cover
 * the shortfall from the player's ProjectE EMC network.
 *
 * From bytecode analysis: BG2 works on an internal COPY of the neededItems list,
 * so the original list is unmodified when our hook fires. We calculate the shortfall
 * by comparing neededItems against what the player currently has in their inventory.
 */
@Mixin(value = BuildingUtils.class, remap = false)
public abstract class MixinBuildingUtils {

    @Inject(
            method = "removeStacksFromInventory(Lnet/minecraft/world/entity/player/Player;Ljava/util/List;ZLnet/minecraft/core/GlobalPos;Lnet/minecraft/core/Direction;)Z",
            at = @At("RETURN"),
            cancellable = true,
            remap = false
    )
    private static void bg2emc_injectEMCFallback(
            Player player,
            List<ItemStack> neededItems,
            boolean simulate,
            GlobalPos boundPos,
            Direction direction,
            CallbackInfoReturnable<Boolean> cir) {

        // Only act when BG2 returned false (couldn't fulfil everything normally)
        if (Boolean.TRUE.equals(cir.getReturnValue())) return;

        boolean allCovered = EMCBridge.tryFulfillFromEMC(player, neededItems, simulate);
        if (allCovered) {
            cir.setReturnValue(Boolean.TRUE);
        }
    }
}
