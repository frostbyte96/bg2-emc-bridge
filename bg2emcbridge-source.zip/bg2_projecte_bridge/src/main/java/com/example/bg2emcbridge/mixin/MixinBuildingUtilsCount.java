package com.example.bg2emcbridge.mixin;

import com.direwolf20.buildinggadgets2.util.BuildingUtils;
import com.example.bg2emcbridge.integration.EMCClientCache;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hooks countItemStacks so ghost block previews turn green for items
 * the player can afford from their EMC network.
 *
 * We always add the EMC-affordable count on top of whatever BG2 found in
 * inventory/Curios. This means even if you have 5 stone in your inventory
 * and need 20, the preview shows all 20 as available because the shortfall
 * is covered by EMC.
 */
@Mixin(value = BuildingUtils.class, remap = false)
public abstract class MixinBuildingUtilsCount {

    @Inject(
            method = "countItemStacks(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;)I",
            at = @At("RETURN"),
            cancellable = true,
            remap = false
    )
    private static void bg2emc_addEMCCount(
            Player player,
            ItemStack itemStack,
            CallbackInfoReturnable<Integer> cir) {

        int emcCount = EMCClientCache.getAffordableCount(player, itemStack);
        if (emcCount > 0) {
            // Add EMC count on top of whatever BG2 already found in inventory.
            // Cap at MAX_VALUE/2 to avoid overflow if someone adds to an already
            // large number.
            int existing = cir.getReturnValue();
            int combined = (existing > Integer.MAX_VALUE / 2) ? existing : existing + emcCount;
            cir.setReturnValue(combined);
        }
    }
}
